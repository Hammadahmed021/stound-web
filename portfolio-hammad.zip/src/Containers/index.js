export { default as Banner } from './Banner';
export { default as About } from './About';
export { default as Contact } from './Contact';
export { default as Service } from './Service';
export { default as Work } from './Work';